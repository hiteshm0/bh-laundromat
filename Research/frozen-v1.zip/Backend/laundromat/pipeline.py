"""The deterministic scan controller combines static evidence with the one supported verifier."""

import subprocess
import time
from importlib.metadata import version
from pathlib import Path

from . import detect, repair
from .workspace import digest

ERRORS = (OSError, ValueError, KeyError, TypeError, AttributeError, subprocess.TimeoutExpired)


def inspect(request, files, *, model_only=False, model_context=None):
    hits, coverage, signals = [], {}, []
    issues = list(request["snapshot"]["issues"])
    if request.get("task_status", "completed") != "completed":
        issues.append(request["task_status"])
    result = dict(
        findings=hits,
        coverage=coverage,
        issues=issues,
        dependency_changes=signals,
        push_decision={
            "action": "not evaluated",
            "reason": "Snapshot review; outgoing history is evaluated at push.",
        },
        versions={
            "semgrep": version("semgrep"),
            "rules": {
                p.name: digest(p.read_bytes()) for p in detect.RULES.iterdir() if p.is_file()
            },
        },
    )
    for kind in ("secret", "query", "guard", "dependency", "package metadata"):
        coverage[kind] = {"status": "outside scope", "paths": []}

    def run(kind, paths, operation):
        check = coverage[kind]
        check["paths"].extend(paths)
        try:
            operation()
            if check["status"] != "incomplete":
                check["status"] = "complete"
        except ERRORS as exc:
            check["status"] = "incomplete"
            issues.append(f"{kind}: {exc}")

    def secret(name, data):
        if b"\0" in data:
            raise ValueError(f"{name} binary content outside text coverage")
        hits.extend(detect.secrets(data, name))

    if files:
        try:
            result["versions"]["gitleaks"] = (
                subprocess.check_output(
                    ["gitleaks", "version"], timeout=5, stderr=subprocess.DEVNULL
                )
                .decode()
                .strip()
            )
        except (OSError, subprocess.SubprocessError):
            result["versions"]["gitleaks"] = "unavailable"
    for name, data in files.items():
        run("secret", [name], lambda: secret(name, data))
        leaf = Path(name).name
        if leaf == "routes.js":

            def routes():
                found, observed, problems = detect.guards(data, name)
                hits.extend(found)
                coverage["guard"].setdefault("routes", []).extend(observed)
                if problems:
                    raise ValueError(", ".join(problems))

            run("guard", [name], routes)
        if leaf == "package-lock.json":
            run("dependency", [name], lambda: hits.extend(detect.dependencies(data, name)))
        elif leaf in ("yarn.lock", "pnpm-lock.yaml", "poetry.lock", "Cargo.lock"):
            coverage["dependency"]["status"] = "incomplete"
            issues.append(f"Unsupported lockfile: {name}")
        if leaf == "recorded-package.json":
            run("package metadata", [name], lambda: signals.append(detect.install_change(data)))
    js = {name: data for name, data in files.items() if name.endswith((".js", ".cjs", ".mjs"))}
    if js:

        def query_scan():
            found, actual_version = detect.queries(js)
            result["versions"]["semgrep"] = actual_version
            hits.extend(found)

        run("query", list(js), query_scan)
    for hit in hits:
        if hit["category"] != "query":
            continue
        hit["repair_status"] = "unsupported query style or path"
        if hit["rule"] == "laundromat.interpolated-search" and hit["path"] == "search.js":
            try:
                candidate = repair.propose(
                    files["search.js"],
                    hit,
                    request.get("model", False),
                    fallback=not model_only,
                    model_context=model_context,
                )
                if candidate:
                    result["repair"] = candidate
                    if candidate["verdict"] == "verified" and "task_finished" in request:
                        result["task_to_verified_patch_ms"] = round(
                            (time.time() - request["task_finished"]) * 1000
                        )
                    if candidate["verdict"] == "incomplete":
                        issues.append(candidate["reason"])
            except ERRORS as exc:
                hit["repair_status"] = "verification incomplete"
                issues.append(f"parameter binding: {exc}")
    result["status"] = "incomplete" if issues else "findings" if hits else "clean"
    return result
