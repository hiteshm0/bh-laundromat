"""One local SQLite ledger shared by CLI, worker, API and Git hook."""

import json
import os
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

from .snapshot import TOKEN
from .workspace import LAB, ROOT, digest, json_bytes


def home():
    path = Path(os.getenv("LAUNDROMAT_HOME", ROOT / ".laundromat-history")).resolve()
    if path == LAB or LAB in path.parents:
        raise ValueError("LAUNDROMAT_HOME must be outside the disposable Phase 1 workspace")
    return path


def encoded(value):
    return TOKEN.sub("[redacted]", json.dumps(value, sort_keys=True))


@contextmanager
def database():
    folder = home()
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    db = sqlite3.connect(folder / "history.sqlite", timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS repositories(path TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS scans(id TEXT PRIMARY KEY, repo TEXT, key TEXT UNIQUE, fingerprint TEXT,
            created REAL, status TEXT, request TEXT, result TEXT);
        CREATE TABLE IF NOT EXISTS jobs(scan TEXT PRIMARY KEY, state TEXT, attempts INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS findings(scan TEXT, ordinal INTEGER, data TEXT, PRIMARY KEY(scan,ordinal));
        CREATE TABLE IF NOT EXISTS repairs(scan TEXT PRIMARY KEY, data TEXT);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, scan TEXT, kind TEXT, time REAL);
        CREATE TABLE IF NOT EXISTS acknowledgements(repo TEXT,snapshot TEXT,finding TEXT,PRIMARY KEY(repo,snapshot,finding));
        """)
        db.execute("BEGIN IMMEDIATE")
        yield db
        db.commit()
    finally:
        db.close()


def event(db, sid, kind):
    db.execute("INSERT INTO events(scan,kind,time) VALUES(?,?,?)", (sid, kind, time.time()))


class Conflict(ValueError):
    pass


def submit(request, key=None, *, state="queued"):
    if TOKEN.search(request["snapshot"]["repository"]):
        raise ValueError("Repository path contains sensitive text")
    fingerprint = digest(json_bytes(request))
    logical_key = digest(key.encode()) if key else fingerprint
    with database() as db:
        prev = db.execute("SELECT id,fingerprint FROM scans WHERE key=?", (logical_key,)).fetchone()
        if prev:
            if prev["fingerprint"] != fingerprint:
                raise Conflict("Idempotency key already refers to different content")
            return prev["id"]
        sid = uuid.uuid4().hex
        repo = request["snapshot"]["repository"]
        db.execute("INSERT OR IGNORE INTO repositories VALUES(?)", (repo,))
        db.execute(
            "INSERT INTO scans VALUES(?,?,?,?,?,?,?,NULL)",
            (sid, repo, logical_key, fingerprint, time.time(), state, encoded(request)),
        )
        db.execute("INSERT INTO jobs(scan,state) VALUES(?,?)", (sid, state))
        event(db, sid, state)
    return sid


def finish(sid, result):
    with database() as db:
        if db.execute("SELECT state FROM jobs WHERE scan=?", (sid,)).fetchone()[0] == "done":
            return
        body = dict(result)
        for i, finding in enumerate(body.pop("findings", [])):
            db.execute("INSERT INTO findings VALUES(?,?,?)", (sid, i, encoded(finding)))
        repair = body.pop("repair", None)
        if repair:
            db.execute("INSERT INTO repairs VALUES(?,?)", (sid, encoded(repair)))
        db.execute(
            "UPDATE scans SET status=?,result=? WHERE id=?", (result["status"], encoded(body), sid)
        )
        db.execute("UPDATE jobs SET state='done' WHERE scan=?", (sid,))
        event(db, sid, result["status"])


def detail(sid):
    with database() as db:
        row = db.execute("SELECT * FROM scans WHERE id=?", (sid,)).fetchone()
        if row is None:
            raise KeyError("Unknown scan")
        repair = db.execute("SELECT data FROM repairs WHERE scan=?", (sid,)).fetchone()
        findings = [
            json.loads(r[0])
            for r in db.execute("SELECT data FROM findings WHERE scan=? ORDER BY ordinal", (sid,))
        ]
        job = dict(db.execute("SELECT state,attempts FROM jobs WHERE scan=?", (sid,)).fetchone())
        return {
            **json.loads(row["request"]),
            **json.loads(row["result"] or "{}"),
            "id": sid,
            "created": row["created"],
            "status": row["status"],
            "job": job,
            "findings": findings,
            "repair": json.loads(repair[0]) if repair else None,
        }


def listing():
    result = []
    with database() as db:
        counts = {}
        for sid, category, n in db.execute(
            "SELECT scan,json_extract(data,'$.category'),count(*) FROM findings GROUP BY 1,2"
        ):
            counts.setdefault(sid, {})[category] = n
        for row in db.execute("""SELECT id,created,status,repo,json_extract(request,'$.trigger') AS trigger,
                json_extract(request,'$.snapshot.sha256') AS sha,json_extract(result,'$.coverage') AS coverage
                FROM scans ORDER BY created DESC,id"""):
            result.append(
                dict(
                    id=row["id"],
                    created=row["created"],
                    status=row["status"],
                    trigger=row["trigger"],
                    snapshot={"repository": row["repo"], "sha256": row["sha"]},
                    coverage=json.loads(row["coverage"] or "{}"),
                    counts=counts.get(row["id"], {}),
                )
            )
    return result


def events(after):
    with database() as db:
        return [
            dict(row)
            for row in db.execute("SELECT * FROM events WHERE id>? ORDER BY id LIMIT 200", (after,))
        ]
